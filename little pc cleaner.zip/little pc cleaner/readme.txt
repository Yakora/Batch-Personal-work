Hi! For security reasons I have disabled the main function of the program, which is to delete temporary files.

-How to activate it to make the program work properly?

You have to right click on "pc cleaner.bat" go to edit and find the line of code that says "REM del *".
At this point you just need to delete the word REM, save the program and run it again.
As you can see (if you have already started the program before reading this text file),
the program will no longer close automatically but will remain open and will ask you whether or not to delete the temporary files that will be displayed on the screen.
-------------------------------------------------- -------------------------------!ATTENTION!---------------- -------------------------------------------------- -----------------------------------------------
ALWAYS make sure! that the directory displayed inside the program is C: \ Users \% yourusername% \ Appdata \ Local \ Temp